# Benchmark protocol

The authoritative Checkpoint 0 protocol is `experiments/checkpoint_0/PROTOCOL.md`, amended by `PROTOCOL_AMENDMENT_V1_1.md` after the preserved Run 001 falsification.

All arms share the same task order, tests, registry content, verifier, and deterministic policy. Arm differences are limited to cross-task state exposure:

- COLD: no persistent capabilities;
- RAW_MEMORY: learned guard lesson is applied globally;
- ALWAYS_ON: all enabled executable capabilities are applied without scope;
- VERIFIED: only enabled, in-scope capabilities are applied in declared order.

No model calls occur in Checkpoint 0. Model tokens and API cost are exactly zero; this is not an estimate of neural-arm cost.

