# Triskelion Verified Capability Runtime

An experimental Python runtime for explicit, executable, scoped, installable, revocable, verifier-governed capabilities around a frozen proposal policy.

Checkpoint 0 validates runtime mechanics in a deterministic Python repair world. It does **not** yet show neural-model improvement. The planned frozen neural arm is `gpt-5.6-luna`; it is currently infrastructure-blocked.

Run:

```bash
python -m unittest discover -s tests -v
python experiments/checkpoint_0/run.py --out /tmp/triskelion-checkpoint-0
```

The experiment refuses to overwrite prior evidence. Run 001 is retained as a composition-order falsification; V1.1 precommits execution precedence and Run 002 passes the intended bounded gates.

Core package: `triskelion/`. Frozen evidence: `experiments/checkpoint_0/run_20260815_002/`.

