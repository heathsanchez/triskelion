# Product API

```python
from triskelion import Runtime

runtime = Runtime("state")
runtime.solve(task)
runtime.explain(task)
runtime.list_capabilities()
runtime.inspect(capability_id)
runtime.install(capability)
runtime.disable(capability_id)
runtime.enable(capability_id)
runtime.uninstall(capability_id)
runtime.verify(capability_id, tasks)
runtime.compose(capability_ids, task)
runtime.revoke(capability_id, evidence)
runtime.export_capability(capability_id, path)
runtime.import_capability(path)
runtime.replay_lineage(capability_id)
runtime.ablate(capability_id, task)
```

All lifecycle mutations persist immediately. Scope is a small declarative DSL rather than arbitrary executable code. Artifact implementations are selected from an explicit allowlist.

