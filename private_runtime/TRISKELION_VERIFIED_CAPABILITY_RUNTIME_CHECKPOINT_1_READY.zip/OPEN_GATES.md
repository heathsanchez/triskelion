# Open gates

1. Execute the precommitted `.github/workflows/river-checkpoint-1.yml` using repository secret `RIVER_API_KEY`; inspect the complete artifact before making any neural claim.
2. Replace hand-curated tasks with frozen independently authored package snapshots and source-distinct protected selection.
3. Add candidate construction by the frozen model; test false promotion, rival hypotheses, protected admission, narrowing, and revocation.
4. Extend the stream until structural-state compression can be fairly compared with linearly growing raw memory.
5. Run the crown-jewel `O1 → O2` discoverability protocol with frozen discovery budget and ancestor ablation. Current transfer is reuse, not changed discoverability.
6. Add exact symbolic and deterministic interactive domains without changing the core registry/lifecycle architecture.
7. Harden artifact execution: signatures, sandbox policy, dependency pinning, resource ceilings, and hostile provenance tests.
8. Implement supersede/recompress transitions and protected-regression replay across the complete registry.
