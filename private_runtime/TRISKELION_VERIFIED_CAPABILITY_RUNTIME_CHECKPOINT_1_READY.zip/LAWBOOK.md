# Lawbook

## L1 — Retention does not imply activation

Status: SUPPORTED in Checkpoint 0. An enabled capability is selected only if its serialized scope matches. The scoped arm beat the always-on arm 6/6 to 5/6.

## L2 — Successful candidates are replayed

Status: PROVEN by implementation and run evidence. The verifier reruns every successful candidate in a fresh subprocess before returning success.

## L3 — Composition order is semantic state

Status: SUPPORTED. Run 001 showed that lexical ordering changed behavior. V1.1 requires declared execution precedence with capability-ID tie-breaking.

## L4 — Import validates artifact identity

Status: PROVEN by unit test. Import recomputes the artifact hash and rejects mismatches.

