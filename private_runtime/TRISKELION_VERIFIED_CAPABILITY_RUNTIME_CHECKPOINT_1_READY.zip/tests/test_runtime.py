import tempfile
import unittest
from pathlib import Path

from triskelion.models import Capability, Task
from triskelion.runtime import Runtime
from triskelion.scope import matches_scope


def cap() -> Capability:
    return Capability(
        capability_id="c1", name="guard", version="1", type="source_transform",
        artifact={"name": "guard_zero_division"}, interface={"input": "source", "output": "source"},
        preconditions=[], postconditions=[],
        scope={"field": "metadata.policy", "equals": "default"},
        applicability_test="metadata policy", status="verified",
    )


def task(policy="default") -> Task:
    return Task("t", "def f(x, y):\n    return x / y\n", [
        {"function": "f", "args": [2, 1], "expected": 2.0},
        {"function": "f", "args": [1, 0], "expected": 0.0},
    ], {"policy": policy})


class RuntimeTests(unittest.TestCase):
    def test_scope_and_lifecycle(self):
        with tempfile.TemporaryDirectory() as raw:
            runtime = Runtime(Path(raw))
            runtime.install(cap())
            self.assertTrue(matches_scope(runtime.registry.capabilities["c1"].scope, task()))
            self.assertTrue(runtime.solve(task())["verdict"]["passed"])
            runtime.disable("c1")
            self.assertFalse(runtime.solve(task())["verdict"]["passed"])
            runtime.enable("c1")
            self.assertTrue(runtime.solve(task())["verdict"]["passed"])

    def test_export_import_hash(self):
        with tempfile.TemporaryDirectory() as raw:
            tmp_path = Path(raw)
            runtime = Runtime(tmp_path / "one")
            runtime.install(cap())
            artifact = tmp_path / "cap.json"
            runtime.export_capability("c1", artifact)
            fresh = Runtime(tmp_path / "two")
            fresh.import_capability(artifact)
            self.assertTrue(fresh.inspect("c1")["enabled"])

    def test_out_of_scope_not_selected(self):
        with tempfile.TemporaryDirectory() as raw:
            runtime = Runtime(Path(raw))
            runtime.install(cap())
            self.assertEqual(runtime.closure(task("raise")), [])


if __name__ == "__main__":
    unittest.main()
