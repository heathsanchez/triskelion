# TRISKELION VERIFIED CAPABILITY RUNTIME — CHECKPOINT 0

Date: 2026-08-15 (Pacific/Auckland). Revision: V1.1.

## 1. Frozen base model

Planned neural arm: `gpt-5.6-luna`, reasoning effort `low`, maximum output 1,800 tokens, fixed structured response contract. Status: **INFRASTRUCTURE-BLOCKED** because no callable credential/endpoint is configured in this workspace.

Executed substrate: `deterministic-constructor-v0`. Its results validate runtime mechanics only and use zero model tokens.

## 2. Runtime architecture

`Runtime` orchestrates a persistent JSON registry, serializable scope DSL, Python AST artifacts, isolated verifier, lifecycle operations, provenance ledger, and development graph. Durable state excludes raw transcripts.

## 3–4. Domain and verifier

The first domain is deterministic Python source repair. The verifier runs candidates twice in fresh temporary subprocesses using `python -B`, `PYTHONDONTWRITEBYTECODE=1`, cache purge, exact tests, and a timeout.

## 5. Capability schema

The schema implements executable artifact, typed interface, pre/postconditions, explicit scope/applicability, dependencies/composition/conflicts, acquisition evidence, protected tests, transfer, ablation, counterexamples, revocation, costs, lifecycle status, enable state, and artifact hash.

## 6–8. Arms, split, and metrics

Six tasks from six source groups were frozen: acquisition, source-distinct transfer, two near-scope negatives, composition, and no-capability control. Arms were COLD, RAW_MEMORY, ALWAYS_ON, and VERIFIED. Metrics include exact success, false/missed activation, latency, state bytes, transfer, ablation, and model tokens.

| Arm | Verified tasks | False activation |
|---|---:|---:|
| COLD | 3/6 | 0% |
| RAW MEMORY | 4/6 | 50.0% |
| ALWAYS-ON | 5/6 | 66.7% |
| VERIFIED SCOPED | 6/6 | 0% |

## 9. First capability experiment

`PY.ZERO_DIVISION_DEFAULT.V1` is an AST transformation scoped to explicit contracts requiring a `0.0` default for a zero divisor. Old closure was empty and the acquisition task failed. Candidate verification passed; installation closed the task; disabling restored failure; enabling restored success. A different function/source group passed, and capability ablation restored its failure.

## 10. Demo path

Fresh runtime import of the compact capability artifact passed without the acquisition transcript. Explicit composition with `PY.ROUND_DIVISION_2.V1` passed with zero new promotion.

Run 001 remains an important negative: undeclared composition order caused VERIFIED to score 5/6. V1.1 added explicit execution precedence; Run 002 reached 6/6.

Compression is **not established**: on this six-task stream, registry state (4,791 bytes) exceeded the raw task corpus (3,113 bytes).
