# Protocol amendment V1.1

Run 001 is preserved. It exposed an under-specified composition order: capability IDs were sorted lexically, causing `ROUND_DIVISION` to rewrite the direct division before `ZERO_DIVISION_DEFAULT` inspected it. VERIFIED therefore scored 5/6 even though the explicitly ordered composition check passed.

V1.1 makes one architectural change: executable capability artifacts declare `execution_order`; zero guarding is 10 and rounding is 20. Runtime routing sorts by this field and then capability ID. Task corpus, split, scope predicates, verifier, policy, seed, and budgets are unchanged.

This amendment was written after Run 001 and before Run 002. Run 001 remains a valid negative result for V1.

