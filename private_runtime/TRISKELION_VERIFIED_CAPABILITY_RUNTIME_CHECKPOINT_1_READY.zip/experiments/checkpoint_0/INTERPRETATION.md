# Interpretation template

This file is intentionally precommitted before results.

- If install passes, disable fails, and fresh import passes: support only the claim that the runtime can preserve a compact executable learning object independently of its acquisition transcript.
- If VERIFIED beats ALWAYS_ON on exact success and false activation: support only the claim that explicit scope improves this protected suite.
- If source-distinct transfer passes and ablation restores failure: support causal reuse in this bounded software world.
- If composition passes with zero promotions: record CLOSURE, not invention.
- Do not infer frozen-neural-model improvement until the neural arm executes.
- Any verifier process error is INFRASTRUCTURE-BLOCKED, not a task failure.

